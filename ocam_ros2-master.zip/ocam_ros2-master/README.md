# ocam_ros2

This package seamlessly integrates OCam with ROS 2, enabling real-time image streaming for your robotic applications.

```cpp
ros2 launch ocam_ros2 ocam_ros.launch.py 
```
