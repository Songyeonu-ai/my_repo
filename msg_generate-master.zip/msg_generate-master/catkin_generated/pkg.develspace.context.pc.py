# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/robit/catkin_ws/devel/include".split(';') if "/home/robit/catkin_ws/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "std_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "msg_generate"
PROJECT_SPACE_DIR = "/home/robit/catkin_ws/devel"
PROJECT_VERSION = "0.0.0"
